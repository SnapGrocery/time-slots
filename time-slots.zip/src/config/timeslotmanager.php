
<?php

return [
    // Configuration options for the TimeSlotManager package
];
